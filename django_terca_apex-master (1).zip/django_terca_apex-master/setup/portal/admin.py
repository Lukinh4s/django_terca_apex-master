from django.contrib import admin

from .models import PortalInfo

admin.site.site_header = 'Portal de Noticias'

class ListPortalInfo(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'create_at')
    list_display_links = ('id', 'titulo')
    search_fields = ('id',)

admin.site.register(PortalInfo, ListPortalInfo)