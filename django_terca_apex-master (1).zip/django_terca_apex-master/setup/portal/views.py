from django.shortcuts import render
from .models import PortalInfo
from artigo.models import Artigo, Categoria

def get_base_context():
   dados_portal = PortalInfo.objects.all().last()

   noticias = Artigo.objects.all()
   categorias = Categoria.objects.all()

   return {
      "titulo": dados_portal.titulo,
      "endereco": dados_portal.endereco,
      "telefone": dados_portal.telefone,
      "email": dados_portal.email,
      "noticias": noticias,
      "destaques": noticias[:2],
      "categorias": categorias
    }

def index(request):

   context = get_base_context()

   return render(request, 'index/index.html', context)