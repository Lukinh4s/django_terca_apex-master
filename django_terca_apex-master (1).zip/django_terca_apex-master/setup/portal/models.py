from django.db import models

class PortalInfo(models.Model):
    titulo = models.CharField(max_length=60, blank=True, default='Apex')
    endereco = models.CharField(max_length=120, blank=True)
    telefone = models.CharField(max_length=20, blank=True)
    email = models.CharField(max_length=120, blank=True)
    create_at = models.DateTimeField(auto_now_add=True)
    linkedin = models.CharField(max_length=255, blank=True)
    facebook = models.CharField(max_length=255, blank=True)
    instagram = models.CharField(max_length=255, blank=True)
    youtube = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.titulo} - {self.create_at}"


