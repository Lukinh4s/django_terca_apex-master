from django.urls import path
from . import views

urlpatterns = [
    path('<int:id>', views.get_artigo, name='artigo'),
    path('addcoment/<int:id>', views.add_comentarios, name='comentarios'),
]