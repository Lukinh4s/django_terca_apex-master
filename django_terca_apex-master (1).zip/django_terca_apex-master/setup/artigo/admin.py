from django.contrib import admin

from .models import Artigo, Categoria, Autor

class ListArtigos(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'created_at', 'autor')
    list_display_links = ('id', 'titulo')
    search_fields = ('id',)

admin.site.register(Artigo, ListArtigos)

class ListAutores(admin.ModelAdmin):
    list_display = ('id', 'nome')
    list_display_links = ('id', 'nome')
    search_fields = ('id',)

admin.site.register(Autor, ListAutores)

class ListCategorias(admin.ModelAdmin):
    list_display = ('id', 'nome')
    list_display_links = ('id', 'nome')
    search_fields = ('id',)

admin.site.register(Categoria, ListCategorias)