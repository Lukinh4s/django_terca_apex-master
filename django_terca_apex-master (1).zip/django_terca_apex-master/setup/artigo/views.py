from contextlib import redirect_stderr
from select import select
from django.shortcuts import render, redirect
from portal.views import get_base_context
from .models import Comentarios, Artigo
from .forms import ComentariosForm

def get_artigo(request, id):

    context = get_base_context()

    if Artigo.objects.filter(id=id).exists():
        artigo = Artigo.objects.get(id=id)
        context['artigo'] = artigo
        coment_list = Comentarios.objects.filter(artigo=artigo)
        context['comentarios'] = coment_list
        context['cont_comnentarios'] = len(coment_list)

    context['comentarioForm'] = ComentariosForm


    return render(request, 'artigo/single.html', context)

def add_comentarios(request, id):

    print(f" =================================== {request.POST}")
    if request.method == 'POST':
        form = ComentariosForm(request.POST)
        # form.artigo = Artigo.objects.get(id=id)
        if form.is_valid():
            novosDados = form.save(commit=False)
            novosDados.artigo = Artigo.objects.get(id=id)
            novosDados.save()

    return redirect("index")